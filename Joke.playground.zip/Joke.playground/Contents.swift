import UIKit

var one = "what does a fish without an eye say"
var two = "fsh"


print (one + "\n")
print ("\t" + two)
